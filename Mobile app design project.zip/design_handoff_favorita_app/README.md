# Handoff: Favorita · App de agendamento (cliente + painel do salão)

## Overview
Redesign do app de agendamento do salão **Favorita Beleza e Bem-Estar**. Dois apps no mesmo produto:
- **Cliente**: escolhe serviços (sacola), escolhe profissional/dia/horário, paga (Pix no app ou no salão) e acompanha o status.
- **Salão (dona)**: aprova/reprova pedidos, vê a agenda do dia e o **Financeiro** (faturamento diário + fechamento de caixa).

Repositório de origem: `eduardoamoriminfoprodutos-sys/favorita` (protótipo antigo em `prototipo/index.html`, prints de todas as telas em `prints/`).

## About the Design Files
Os arquivos deste pacote são **referências de design feitas em HTML** — mostram o visual e o comportamento pretendidos, **não são código de produção**. A tarefa é **recriar essas telas no ambiente do app** (ex.: React + Vite, Next.js, React Native/Expo) usando os padrões dessa stack. Se ainda não houver stack definida, recomendação: **React + Vite + Tailwind (PWA mobile-first)** ou **Expo (React Native)** caso queira publicar nas lojas.

Abra `Favorita App Redesign.dc.html` no navegador para ver todas as telas lado a lado.

## Fidelity
**High-fidelity.** Cores, tipografia, espaçamentos, raios e sombras são finais. Recriar pixel-perfect.

## Design Tokens

### Cores
| Token | Hex | Uso |
|---|---|---|
| bg | `#F5F2ED` | fundo das telas (bege) |
| surface | `#FFFFFF` | cards |
| surface-soft | `#F8F5F1` | chips de horário, cards de profissional não selecionados |
| surface-muted | `#F5F2ED` / `#F0EBE5` | botões secundários, divisores |
| ink | `#211B18` | texto principal, botões primários, seleção |
| ink-2 | `#4A403B` | texto secundário forte |
| muted | `#7A6F68` | texto secundário |
| faint | `#9A8F88` / `#BDB3AA` | ícones inativos, indisponível |
| line | `#E8E1D9` / `#EDE7E0` | bordas |
| gold | `#A47A35` | labels de seção (eyebrow), links |
| gold-mid | `#B8893F` | check de selecionado, radio |
| gold-line | `#C9A25E` | borda de selecionado |
| gold-light | `#E2C08A` | texto dourado sobre ink |
| gold-tint | `#F6EEDF` / `#FBF6EE` | fundo de chips/áreas douradas |
| gold-gradient | `linear-gradient(135deg,#CDA866,#A97C36)` | CTA flutuante (sacola, fechar caixa, escolher outro horário) |
| blush | `#EFE3DB` | avatar placeholder |
| success | `#2F7A55` on `#E3F0E8` | Confirmado / Pix pago |
| danger | `#B5453A` on `#F7E4E0` | Não aprovado / Reprovar / badge |
| warning | `#A47A35` on `#F6EEDF` | Aguardando salão |
| pix | `#2B9C8F` on `#E3F3F1` | ícone Pix |
| prof Ana / Duda / Carla | `#C99A87` / `#8FA58C` / `#C9A86A` | cor por profissional na agenda |

### Tipografia
Fonte única: **Montserrat** (Google Fonts, 400/500/600/700).
| Estilo | Tamanho | Peso | Extra |
|---|---|---|---|
| Título de tela (H1) | 28px | 700 | letter-spacing -0.02em, line-height 1.15 |
| Valor grande (Financeiro) | 34px | 700 | -0.03em |
| Título de card | 15px | 600–700 | |
| Corpo | 13–14px | 500 | |
| Meta / legenda | 12–12.5px | 500 | cor muted |
| Eyebrow (label de seção) | 12px | 700 | letter-spacing 0.1em, MAIÚSCULAS, cor gold |
| Pill de status | 10.5–11px | 700 | letter-spacing 0.06em, MAIÚSCULAS |
| Tab bar | 10.5–11px | 500 (ativo 600–700) | |

### Raios
Tela 48 · card grande 20–24 · card 18 · botão 14 · chip horário 11–12 · tile ícone 12 · pill 999.

### Sombras
- Card: `0 1px 2px rgba(33,27,24,.04), 0 10px 24px -14px rgba(33,27,24,.18)`
- CTA dourado: `0 16px 32px -12px rgba(169,124,54,.7)`

### Espaçamento
Margem lateral da tela 16px (cards) / 22px (títulos). Gap entre cards 10–14px. Padding interno de card 14–18px. Base de 4px.

### Layout mobile
Viewport de referência 390×844. Status bar 50px. Tab bar fixa 84px (branca, borda superior `#EDE7E0`). Barras de CTA fixas no rodapé com padding `14px 22px 30px`. CTA flutuante dourado a 96–100px do fundo (acima da tab bar).

## Screens

### 01 · Catálogo (cliente)
- Header: logo `logo-favorita-escura.png` (altura 48px) à esquerda; avatar 50px à direita com anel dourado (`box-shadow: 0 0 0 3px #F5F2ED, 0 0 0 4.5px #C9A25E`). Toque no avatar → Perfil.
- Saudação "Olá, {nome}" (14px muted) + H1 "O que vamos fazer hoje?".
- Chips de categoria com scroll horizontal (Cabelo, Unhas, Sobrancelha e cílios, Estética). Ativo: fundo ink, texto branco.
- Eyebrow "CABELO" + "6 serviços".
- Lista de serviços: cada um é um card branco separado (radius 20, sombra card). Conteúdo: nome (15/600), descrição (13 muted), linha com etiqueta de tempo (fundo `#F5F2ED`, radius 8) + preço (700). Botão 34px à direita: `+` (fundo `#F5F2ED`) / `✓` selecionado (fundo `#B8893F`, branco). Card selecionado ganha borda 1.5px `#C9A25E`.
- Serviço com opções (ex.: Selagem curto/médio/longo): ao tocar `+`, abre bottom sheet para escolher a opção; a opção escolhida aparece como etiqueta dourada ao lado do nome.
- **Sacola flutuante dourada** (aparece com ≥1 serviço): ícone sacola com badge de quantidade, "N serviços · tempo total", total em 17/700, botão branco "Escolher horário" → tela 02.
- Tab bar cliente: Serviços / Horários / Perfil.

### 02 · Agendar (profissional, dia, horário)
- Header: botão voltar 40px circular + "Agendar horário".
- Stepper: Serviços ✓ (dourado) — Horário (ink, atual) — Confirmar (cinza).
- Resumo da sacola (fundo `#F6EEDF`): "Selagem + Escova · 3h15" + link "Editar" (volta para 01).
- Card **Profissional**: scroll horizontal de cards 132px: foto 64px, nome, expediente, **chips de habilidades** (ex.: Corte, Coloração, Selagem). Primeiro card "Qualquer uma" (ícone ✦ sobre ink). Selecionado: fundo `#FBF6EE`, borda `#C9A25E`, check dourado no canto, anel dourado na foto.
- Card **Dia**: navegação de mês ‹ Novembro ›, 7 colunas (dia da semana + número + ponto dourado se tem vaga). Dia fechado (domingo) esmaecido e desabilitado. Selecionado: ink.
- Card **Horário**: segmentado Manhã/Tarde; grade 4 colunas. Disponível: `#F8F5F1`; selecionado: ink; indisponível: borda tracejada + texto riscado, não clicável.
- Barra inferior: "Ter, 17/11 · 09:30 · Ana" + total + botão "Continuar →" (desabilitado até escolher dia e horário).

### 03 · Confirmar e pagar
- Stepper com Serviços ✓, Horário ✓, Confirmar atual.
- Card resumo: faixa ink no topo com data (dia da semana/número) + "09:30 às 12:45" + "com Ana"; abaixo, lista de serviços com preço e Total.
- Card **Pagamento** (ícone cartão + eyebrow): duas opções radio:
  - **Pix agora** — tile com losango Pix; "Devolvido se não aprovar".
  - **No salão** — mini cartão de crédito desenhado; "Cartão de crédito ou dinheiro" (ao escolher, perguntar qual: cartão ou dinheiro).
- Campo Observação (opcional).
- Se não tiver perfil: pedir nome e WhatsApp antes de confirmar.
- CTA: "Pagar R$ X com Pix" (Pix) ou "Enviar pedido" (no salão). Pix → tela de QR + copia-e-cola (ver print `prints/cliente/11-pix-qr-e-copia-e-cola.png`).

### 04 · Meus horários
- H1 + segmentado "Próximos · N" / "Histórico".
- Card por agendamento (radius 22, padding 16/18):
  - Linha 1: pill de status + forma de pagamento à direita.
  - Linha 2: bloco de data 54px (ink; esmaecido se não aprovado) + serviço (15/700), horário início–fim, mini avatar + "com {prof} · R$".
  - Confirmado: divisor + botões "Como chegar" (abre Maps) e "Falar no WhatsApp" (abre wa.me do salão).
  - Não aprovado: caixa de motivo (fundo `#FBF1EE`, ícone "!" vermelho) + botão dourado "Escolher outro horário" (abre 02 com a mesma sacola).
  - Aguardando salão: só informações.

### 05 · Pedidos (salão)
- Header: logo 48px + "PAINEL / Sáb, 14 nov".
- Card ink com 3 números: para aprovar (dourado), confirmados hoje, previsto hoje.
- "Para aprovar" — cards: avatar, nome, serviços · profissional, pill de pagamento (PIX PAGO verde / NO SALÃO cinza), faixa com data/hora e valor, botões **Reprovar** (outline, texto vermelho) e **Aprovar** (ink, 2× largura).
- Tocar no card → resumo completo do pedido (ver prints `prints/salao/02..07`). Reprovar → escolher motivo → notifica cliente; se Pix, dispara estorno.
- Tab bar salão (5): Pedidos (badge vermelho com quantidade) / Agenda / **Financeiro** / Serviços / Equipe.

### 06 · Agenda do dia
- H1 "Agenda" + mês; seletor de dias num card branco (ponto dourado = tem atendimentos).
- 3 mini-cards dourados: Atendimentos, Previsto, Livre.
- Filtro por profissional (chips com bolinha da cor dela).
- Timeline: coluna de hora 50px (início em 13/700, fim em 11 faint) + card do atendimento com barra lateral da cor da profissional, nome, serviço · profissional, avatar da profissional, pill de pagamento.
- Intervalos livres: caixa tracejada "Livre até HH:MM" + ação "+ Encaixe".

### 07 · Financeiro (NOVO)
- H1 "Financeiro" + seletor de data ("Hoje, 14 nov ▾").
- Card ink: eyebrow "FATURAMENTO DO DIA", valor 34/700, "N lançamentos · atualizado ao aprovar", barras de progresso por forma: Pix (`#4FC1B3`), Cartão (`#D9B56F`), Dinheiro (`#9DBF92`).
- Filtros: Todos / Pix / Cartão / Dinheiro.
- Lista de lançamentos: tile por tipo (Pix losango, cartão, "R$" dinheiro), cliente, serviço · "aprovado HH:MM", valor "+ R$".
- CTA dourado fixo **"Fechar caixa do dia"** → resumo do fechamento (totais por forma, confirmar), trava os lançamentos do dia.

## Interactions & Behavior / Regras de negócio
- **Todo agendamento passa pela aprovação da dona.**
- **Pix**: valor calculado no servidor a partir da sacola (Mercado Pago). Pedido só chega para a dona depois do Pix pago. Se reprovado, o Pix é estornado.
- **No salão**: cliente escolhe cartão de crédito ou dinheiro; pedido vai direto para aprovação.
- **Ao aprovar** um pedido → cria automaticamente um **lançamento no Financeiro** com forma de pagamento, valor, cliente, serviços, profissional e horário da aprovação. (Pix: lançado como recebido. Cartão/dinheiro: lançado como previsto e marcado recebido quando o atendimento for concluído — confirmar com a dona qual regra prefere.)
- Ao reprovar → motivo obrigatório; status da cliente vira "Não aprovado" com motivo.
- Horários indisponíveis = expediente da profissional − agendamentos aprovados/pendentes − duração total da sacola.
- "Qualquer uma" = atribui a primeira profissional livre com a habilidade necessária.
- Transições: telas push (slide 250ms ease-out); bottom sheets slide-up 220ms; seleção de chip/card troca instantânea; CTA flutuante entra com fade+translateY(12px) 200ms.
- Estados vazios: sacola vazia esconde a barra; "Meus horários" sem itens → mensagem + botão "Agendar agora"; Financeiro sem lançamentos → "Nenhum pagamento hoje".

## State / Data model (sugestão)
- `Categoria {id, nome, ordem}`
- `Servico {id, categoriaId, nome, descricao, duracaoMin, preco, ativo, opcoes?: [{nome, duracaoMin, preco}]}`
- `Profissional {id, nome, foto, cor, habilidades: string[], expediente: {diaSemana, inicio, fim}[]}`
- `Cliente {id, nome, whatsapp, endereco, foto}`
- `Agendamento {id, clienteId, profissionalId, itens:[{servicoId, opcao?, preco, duracao}], inicio, fim, total, pagamento:'pix'|'cartao'|'dinheiro', pixStatus?, status:'aguardando'|'confirmado'|'reprovado'|'concluido', motivo?, observacao?}`
- `Lancamento {id, agendamentoId, forma, valor, data, aprovadoEm, recebido:boolean, caixaId?}`
- `FechamentoCaixa {id, data, totalPix, totalCartao, totalDinheiro, total, fechadoEm}`
- Estado da cliente no fluxo: `sacola[]`, `profissionalId`, `dia`, `horario`, `pagamento`, `observacao`.

## Assets
- `logo-favorita-escura.png` (logo para fundo claro) e `logo-favorita.png` (versão clara, para fundo escuro) — vindos de `prototipo/` no repositório.
- Ícones: traço simples 1.8px, 22px (sacola, calendário, pessoa, inbox, lista, equipe, carteira). Usar **Lucide** (`shopping-bag`, `calendar`, `user`, `inbox`, `list`, `users`, `wallet`, `lock`).
- Fotos de profissionais/clientes: placeholders com iniciais (fundo `#EFE3DB`) até ter fotos reais.

## Files
- `Favorita App Redesign.dc.html` — todas as 7 telas (abrir no navegador).
- `logo-favorita-escura.png`, `logo-favorita.png`.
- Telas não redesenhadas (Pix QR, Perfil, Resumo do pedido, Serviços, Categorias, Equipe): seguir os prints em `prints/` do repositório aplicando estes tokens.
